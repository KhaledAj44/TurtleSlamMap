# map2

Coordinates in [map2.csv](map2.csv) coordinates, file indices starting at 1,1:
- Origin: Line 3, Column 3. At resolution 1 pixel/meter = 1 meter/pixel: X = 2.5 m, Y = 2.5 m
- Destiny: Line 11, Column 8. At resolution 1 pixel/meter = 1 meter/pixel: X = 10.5 m, Y = 7.5 m

![map2.png](map2.png)
